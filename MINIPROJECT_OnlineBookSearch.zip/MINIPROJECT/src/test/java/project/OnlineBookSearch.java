package project;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.PageLoadStrategy;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.github.bonigarcia.wdm.WebDriverManager;

public class OnlineBookSearch {

	public static WebDriver driver;
	public static Properties p = new Properties();

	public static void setUpBrowser() throws IOException {
		// To Read the data from the properties file
		FileInputStream fileInputStream = new FileInputStream("./src/test/resources/config.properties");
		p = new Properties();
		p.load(fileInputStream);

		// ChooseWebDriver ,Use Chrome if not specified
		String browser = p.getProperty("browser").toLowerCase();
		switch (browser) {
		case "chrome":
			ChromeOptions chromeoptions = new ChromeOptions();
			chromeoptions.setPageLoadStrategy(PageLoadStrategy.EAGER);
			driver = new ChromeDriver(chromeoptions);
			break;
		case "firefox":
			FirefoxOptions firefoxoptions = new FirefoxOptions();
			firefoxoptions.setPageLoadStrategy(PageLoadStrategy.EAGER);
			driver = new FirefoxDriver(firefoxoptions);
			break;
		case "edge":
			EdgeOptions edgeoptions = new EdgeOptions();
			edgeoptions.setPageLoadStrategy(PageLoadStrategy.EAGER);
			driver = new EdgeDriver(edgeoptions);
			break;
		default:
			ChromeOptions chromeoptions1 = new ChromeOptions();
			chromeoptions1.setPageLoadStrategy(PageLoadStrategy.EAGER);
			driver = new ChromeDriver(chromeoptions1);
			break;
		}
	}

	public static void navigateToBookswagon() {
		// Launch the Browser go to Bookswagon Website
		driver.get("https://www.bookswagon.com");
		// Maximize the window
		driver.manage().window().maximize();
	}

	public static void clickOnSearchBoxWithSearchItem() {
		// Find the Search Textbox and read the SearchKey from Properties file
		WebElement searchBox = driver.findElement(By.id("inputbar"));
		searchBox.sendKeys(p.getProperty("searchKey"));

		// Click on Search Button
		WebElement searchButton = driver.findElement(By.id("btnTopSearch"));
		searchButton.click();

	}

	public static void searchResults() {
		WebElement resultCount = driver.findElement(By.cssSelector("div.preferences-show > b"));
		// Convert the result count text to an integer
		int numberOfBooks = Integer.parseInt(resultCount.getText());

		// Check if number of search results is greater than searchCount
		int searchCount = Integer.parseInt(p.getProperty("searchCount"));

		if (numberOfBooks > searchCount) {
			System.out.println("Number of Search Results = " + numberOfBooks + " which is greater than " + searchCount);
		} else {
			System.out.println("Number of Search Results = " + numberOfBooks + " which is less than " + searchCount);
		}

	}

	public static void sortBooks() throws InterruptedException {
		// Click on sort by Price - Low to High
		WebElement sortElement = driver.findElement(By.id("ddlSort"));
		sortElement.sendKeys(p.getProperty("sortBy"));

		// Wait for the page to update after sorting
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
		wait.until(ExpectedConditions.stalenessOf(sortElement));

		// Find the sort dropdown again
		sortElement = driver.findElement(By.id("ddlSort"));

		// Select the desired option in the dropdown
		Select sortPrice = new Select(sortElement);
		sortPrice.selectByVisibleText(p.getProperty("sortBy"));

	}

	public static void printBookResults() {
		List<WebElement> bookResults = driver.findElements(By.className("list-view-books"));

		// Print Book Information
		int numberOfResults = Math.min(Integer.parseInt(p.getProperty("numberOfResults")), bookResults.size());

		for (int i = 0; i < numberOfResults; i++) {
			WebElement book = bookResults.get(i);
			String bookTitle = book.findElement(By.className("title")).getText();
			String bookPrice = book.findElement(By.className("sell")).getText();
			System.out.println("Book" + (i + 1) + " : " + bookTitle + " , " + " Price = " + bookPrice);
		}

	}

	public static void main(String[] args) {
		try {
			setUpBrowser();
			navigateToBookswagon();
			clickOnSearchBoxWithSearchItem();
			searchResults();
			sortBooks();
			printBookResults();

		} catch (IOException e) {
			System.out.println("Please enter correct path for properties file.");
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();

		} finally {
			if (driver != null) {
				// close the Browser
				driver.quit();

			}
		}
	}
}